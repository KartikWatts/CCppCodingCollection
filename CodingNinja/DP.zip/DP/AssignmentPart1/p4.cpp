#include <iostream>
#include <unordered_map>

using namespace std;

int main()
{
    int n;
    cin >> n;
    int *a = new int[n];
    unordered_map<int, int> m;
    int total = 0, max = 0;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
        m[a[i]]++;
        total += a[i];
    }

    for (auto it : m)
    {
        int temp = total;
        if (m.find(it.first + 1) != m.end())
        {
            temp -= m[it.first + 1] * (it.first + 1);
        }
        if (m.find(it.first - 1) != m.end())
        {
            temp -= m[it.first - 1] * (it.first - 1);
        }
        if (temp > max)
        {
            max = temp;
        }
    }

    cout << max;
    delete[] a;
    return 0;
}