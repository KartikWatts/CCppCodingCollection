#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n;
    int mod = pow(10, 9) + 7;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    map<int, unsigned long long> map, mRep;
    for (int i = 0; i < n; i++)
    {
        for (auto it : map)
        {
            int gcdVal = __gcd(it.first, a[i]);
            map[gcdVal] = (map[gcdVal] + it.second);
        }
        if (mRep[a[i]] == 0)
        {
            map[a[i]]++;
            mRep[a[i]]++;
        }
    }
    cout << "GCD Values of all types are: " << endl;
    for (auto it : map)
    {
        cout << it.first << ": " << it.second << "\t";
    }
    cout << "\nResult: " << endl;
    cout << map[1] % mod;
}